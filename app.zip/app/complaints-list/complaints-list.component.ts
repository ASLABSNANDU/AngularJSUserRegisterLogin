import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ComplaintsData } from '../shared/complaints-data';

@Component({
  selector: 'app-complaints-list',
  templateUrl: './complaints-list.component.html',
  styleUrls: ['./complaints-list.component.sass']
})
export class ComplaintsListComponent implements OnInit {

  constructor(private http:HttpClient){

  }  
  ngOnInit(): void {
  }

public complID:boolean=false;
  
private complAllData : any | undefined;
public complAllDataArr : Array<ComplaintsData> | undefined;
private filter: any;

 getAllComplaintsData() {
  console.log('getAllComplaintsData'); 
  if(this.complAllDataArr != null  ){
    this.complID = true;
  }else{

    this.http.get('http://localhost:2501/apis/getFullDetailsOfComplaints').subscribe( (cData) => {
      this.complAllData = cData;

      if(this.complAllData.flag = true){
        console.log('if ' , this.complAllData.flag );
        this.complID = true;
        this.complAllDataArr = this.complAllData.ret;
        console.log(this.complAllData);  
      }else{
 console.log('else ' , cData);
      }
    
      } )
    }
  }
  hideComplaintsData(){
    console.log('hideComplaintsData');
    this.complID = false;
  }

}
