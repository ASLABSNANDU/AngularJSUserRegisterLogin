import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ComplaintsListComponent } from './complaints-list/complaints-list.component';
import { MastersDataComponent } from './masters-data/masters-data.component';
import { UserLoginComponent } from './user-login/user-login.component';
import { UserSignUpComponent } from './user-sign-up/user-sign-up.component';

const routes: Routes = [
  { path: "complaints", component: ComplaintsListComponent },
  { path: "login", component: UserLoginComponent },
  { path: "signUp", component: UserSignUpComponent },
  { path: "mastersData", component: MastersDataComponent }
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routingComponents = [ComplaintsListComponent, MastersDataComponent, UserLoginComponent, UserSignUpComponent];
