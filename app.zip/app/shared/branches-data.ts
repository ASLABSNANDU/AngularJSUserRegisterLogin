export class BranchesData{
    branch: String | undefined;
    branchDescription: String | undefined;
}