export class ComplaintsData {
    compaintid: number | undefined;
    userId: String | undefined;
    actDate: Date | undefined;
    actTime: Date | undefined;
    departments: String | undefined;
    complaintTitle: String | undefined;
    complaintDescription: String | undefined;
    tags: String | undefined;
    visibility: String | undefined;
    comments: String | undefined;
    status: String | undefined;
    idStatus: String | undefined;
    likedCounts: number | undefined;
    disLikedCounts: number | undefined;
    likedisLikeStatus: boolean | undefined;
}
