import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-sign-up',
  templateUrl: './user-sign-up.component.html',
  styleUrls: ['./user-sign-up.component.sass']
})
export class UserSignUpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
