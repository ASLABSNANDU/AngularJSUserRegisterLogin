import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { BranchesData } from '../shared/branches-data';

@Component({
  selector: 'app-masters-data',
  templateUrl: './masters-data.component.html',
  styleUrls: ['./masters-data.component.sass']
})
export class MastersDataComponent implements OnInit {

  constructor(private http:HttpClient) { }

  ngOnInit(): void {
  }

  public branchesID:boolean=false;
  public departmentsID:boolean=false;
  public userTypesID:boolean=false;
public branchesAllDataArr : Array<BranchesData> | undefined;
private branchesAllData : any | undefined;
  getAllBranchesData(){

    console.log('getAllBranchesData' , this.branchesAllDataArr); 
    if(this.branchesAllDataArr != null ){
      this.branchesID = true;
    }else{
      console.log('get All Branches Data' , this.branchesAllDataArr); 

      this.http.get('http://localhost:2501/rest/branchesAll').subscribe( (cData) => {
        this.branchesAllData = cData;
        console.log('get All Branches Data' , this.branchesAllData);
          this.branchesID = true;
          this.branchesAllDataArr = this.branchesAllData ;
          console.log(this.branchesAllDataArr);  
       
        } )
      }
  }
  hideBranchesData(){
    console.log('hideBranchesData');
    this.branchesID = false;
  }
  getAllDepartmentsData(){

  }
  hideDepartments(){
    console.log('hideDepartments');
    this.departmentsID = false;
  }
  getAllUserTypesData(){

  }
  hideUserTypesData(){
    console.log('hideUserTypesData');
    this.userTypesID = false;
  }
}
