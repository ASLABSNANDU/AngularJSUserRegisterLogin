import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MastersDataComponent } from './masters-data.component';

describe('MastersDataComponent', () => {
  let component: MastersDataComponent;
  let fixture: ComponentFixture<MastersDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MastersDataComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MastersDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
