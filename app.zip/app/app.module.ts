import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA  } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule, routingComponents } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MastersDataComponent } from './masters-data/masters-data.component';
//import { UserLoginComponent } from './user-login/user-login.component';
///import { UserSignUpComponent } from './user-sign-up/user-sign-up.component';
//import { ComplaintsListComponent } from './complaints-list/complaints-list.component';
//import { RegUsersListComponent } from './reg-users-list/reg-users-list.component';


const routes: Routes = [
  { path: 'home', component: AppComponent },
  //{ path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'complaints', redirectTo: '/allAomplaints', pathMatch: 'full' },
  { path: 'masters', redirectTo: '/allMasters', pathMatch: 'full' }
];


@NgModule({
  declarations: [
    AppComponent, routingComponents, MastersDataComponent
    //, UserLoginComponent, UserSignUpComponent, ComplaintsListComponent, RegUsersListComponent
  ],
  imports: [
    CommonModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule, 
    RouterModule.forRoot(routes)
  ],
  exports: [
    RouterModule
  ],
  providers: [],
  bootstrap: [AppComponent], 
  schemas: [CUSTOM_ELEMENTS_SCHEMA , NO_ERRORS_SCHEMA  ]
})
export class AppModule { }
